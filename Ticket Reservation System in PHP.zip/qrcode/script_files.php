<!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    
    
    <script type="text/javascript" charset="utf-8" src="data-table/js/jquery.dataTables.js"></script>
    <script type="text/javascript" charset="utf-8" src="data-table/js/DT_bootstrap.js"></script>
    <script type="text/javascript" charset="utf-8" src="data-table/js/DT_bootstrap2.js"></script>
    <script type="text/javascript" charset="utf-8" src="data-table/js/DT_bootstrap3.js"></script>
    <script type="text/javascript" charset="utf-8" src="data-table/js/DT_bootstrap4.js"></script>
    <script type="text/javascript" charset="utf-8" src="data-table/js/DT_bootstrap5.js"></script>
    <script type="text/javascript" charset="utf-8" src="data-table/js/DT_bootstrap6.js"></script>
    <script type="text/javascript" charset="utf-8" src="data-table/js/DT_bootstrap7.js"></script>
    <script type="text/javascript" charset="utf-8" src="data-table/js/DT_bootstrap8.js"></script>
    <script type="text/javascript" charset="utf-8" src="data-table/js/DT_bootstrap9.js"></script>
    <script type="text/javascript" charset="utf-8" src="data-table/js/DT_bootstrap10.js"></script>
    <script type="text/javascript" charset="utf-8" src="data-table/js/DT_bootstrap11.js"></script>
    <script type="text/javascript" charset="utf-8" src="data-table/js/DT_bootstrap12.js"></script>
    
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="js/charts-home.js"></script>
    <!-- Main File-->
    <script src="js/front.js"></script>